-- MariaDB dump 10.19  Distrib 10.6.17-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: kodaposc_bebras_db
-- ------------------------------------------------------
-- Server version	10.6.17-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kontak`
--

DROP TABLE IF EXISTS `kontak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kontak` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `institusi` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kontak`
--

LOCK TABLES `kontak` WRITE;
/*!40000 ALTER TABLE `kontak` DISABLE KEYS */;
/*!40000 ALTER TABLE `kontak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kontak_detail`
--

DROP TABLE IF EXISTS `kontak_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kontak_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `kontak_id` bigint(20) unsigned NOT NULL,
  `tipe` enum('email','url','telepon','fax','lainnya') NOT NULL,
  `nilai` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kontak_detail_kontak_id_foreign` (`kontak_id`),
  CONSTRAINT `kontak_detail_kontak_id_foreign` FOREIGN KEY (`kontak_id`) REFERENCES `kontak` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kontak_detail`
--

LOCK TABLES `kontak_detail` WRITE;
/*!40000 ALTER TABLE `kontak_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `kontak_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `latihan`
--

DROP TABLE IF EXISTS `latihan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `latihan` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `link` varchar(255) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `latihan`
--

LOCK TABLES `latihan` WRITE;
/*!40000 ALTER TABLE `latihan` DISABLE KEYS */;
/*!40000 ALTER TABLE `latihan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_soal`
--

DROP TABLE IF EXISTS `menu_soal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_soal` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `nama_menu` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `urutan` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_soal_slug_unique` (`slug`),
  KEY `menu_soal_parent_id_foreign` (`parent_id`),
  CONSTRAINT `menu_soal_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `menu_soal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_soal`
--

LOCK TABLES `menu_soal` WRITE;
/*!40000 ALTER TABLE `menu_soal` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_soal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_09_10_024414_create_roles_table',1),(5,'2025_09_10_024529_create_role_user_table',1),(6,'2025_09_11_143335_create_kontak_table',1),(7,'2025_09_11_143654_create_kontak_detail_table',1),(8,'2025_09_12_111313_create_latihan_table',1),(9,'2025_09_24_125631_create_tentang_bebras_table',1),(10,'2025_09_25_232644_create_menu_soal_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_user_user_id_foreign` (`user_id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES (1,1,1,NULL,NULL),(2,2,2,NULL,NULL);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES (1,'admin','2025-10-03 05:44:02','2025-10-03 05:44:02'),(2,'user','2025-10-03 05:44:02','2025-10-03 05:44:02');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES ('02KNu63wco3wRoix0KOSs4F2DGvoDnTbEY8eVYJq',NULL,'185.247.137.179','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUnlBazRzajZiZjRlSTYzQ0FpN2ZzcXlwUlVMTVA0THg3eWI3MkZiVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vd3d3LmludGVybmFsLmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1778051119),('1bk7Pe2hvatG5dQEiby4wY6puWsW1btkZQhyKJix',NULL,'54.88.24.205','okhttp/5.3.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoicUhJeUpsSU1kMnVzVFZpNE8wZ25NZFlqM1ppbERxeVVZSHFEcUk2QiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778737616),('1O6xiKc2oleyCxemPCmlYU7wnVPQEBPvv7JnoWJz',NULL,'199.45.155.107','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoieHlDdzlwOE5IWUFvMHo3OFZib0dieHlNZm9wN2VTYlBhNHBtT2t5WiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779217566),('2PCu12skKwjKK3EISlLfAydeUcn55pRQAttDLLsD',NULL,'35.194.18.226','Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNWowc3FadUFHR1FmSHVOVDFTMFlzZHJBN0N4YkVGU0VrQ2dKWmlNZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1777478445),('2zfpJaJXLTZXF1UrHa7B8lH8Kr8BgoNLFDJ9wr3P',NULL,'44.200.173.66','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.7204.23 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYWhFcld1NWdKSWlqU3JhM1dlTmlRVlg5N0pRaGhDakZ1alZ1aEpzNyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778738124),('33XxJolZrlVBXJ8dPeLHFz57J0S8N8GMcORdeqXl',NULL,'66.132.195.70','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUGVyVE9UeG95ZmxKd1pNQnZrM21IeHRtV2Nwc1dWTENYaXRwaXBhMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly93d3cuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777897302),('3mukD4UzImLmIImcX56CrQCcknPQYoeEZGhtPsnk',NULL,'158.173.67.140','','YTozOntzOjY6Il90b2tlbiI7czo0MDoieGtMTHJndFFhOVB4bUprOXFETGFQS2RTMzcwZ01pd2x4cFlaR3RtQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9pbnRlcm5hbC5iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778436724),('3pKQmRQA151vYz6liVA4ibQnGtT4EC2urhqlCatQ',NULL,'34.254.60.189','Mozilla/5.0 (compatible; NetcraftSurveyAgent/1.0; +info@netcraft.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUTduOVhSUDROYlpVTTZKUVFlUmM5eG41WmI5VDlwRnhCMFg5ZjZsQSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vd3d3LmludGVybmFsLmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1778522467),('43MGZMfWsNC4zH7BzdRryUW05sh0U7u4wsALl86i',NULL,'198.235.24.120','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoia0l3eHRDcUNOTk5iOFJsUUxRVHBHQWRSZ3ZzNWdvYlgxenYyZVlhTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778833086),('4Xa5e8oq6afopWjBk0oX1ClFn5Yoa0qnWlhOiZ8V',NULL,'93.158.90.73','Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMlVmS1MwOExsRXJ4cEt1TExVcWJXNFNNeHo0UHNqRzA4WFJPNkVndCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTI6Imh0dHA6Ly93d3cuYmVicmFzLmtvZGFwb3MuY29tL2tlZ2lhdGFuL3dvcmtzaG9wLTIwMTciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1777309199),('52sknopK3QSzojioUmts90KevUplNjbaG2UuI7dx',NULL,'74.7.227.1','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)','YTozOntzOjY6Il90b2tlbiI7czo0MDoibUo2cEUyMjJNWVEzOGRZc1Z2YUVjWnFvRFJ3dkJxV3BFa3hHU2FLbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDk6Imh0dHBzOi8vd3d3LmJlYnJhcy5rb2RhcG9zLmNvbS90ZW50YW5nQmVicmFzL2RkXzUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1777816119),('5AXjJ0YknRJ7HmjSBaPzCjfOVT4FPtj6Zz8458rt',NULL,'93.158.90.72','Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115','YTozOntzOjY6Il90b2tlbiI7czo0MDoiV1ZibWVGOXFNRk9ET0hTazJ3VTdzdzBTUG9icWJpZWx5elRESVczSiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly93d3cuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777309198),('5KVVqhWOXiZwuCQtNfECYfHhathD0WCtzQzZF4Wv',NULL,'44.244.17.154','Mozilla/5.0 (compatible; wpbot/1.4; +https://forms.gle/ajBaxygz9jSR8p8G9)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMFNyd3hlTWg1VTgwNnhBeERLbmk3NXBGeDVXT09PU0pyTk9NdFVmciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778672057),('5xighmR0FTIgnsbgAmRFSlR62uIHlx8KSKTbULV7',NULL,'66.132.195.73','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVdKVW10S2pzZW83VFQ3bHFXdEdxR0xOdDI0M3BuaUlSNUJoWHFzMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vd3d3LmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1777896677),('6mDyUt6KQmEeHkJlAknHHsfc8aojJEcEGWGfaNbD',NULL,'134.122.39.57','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVTZ1eUZWZ052cW1JY2M0TlBZZGl1U3QzQVdhOWw3bW1LeUtuRHhlMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778221412),('6PcPG659WbNP0oCmWPQJPuR04yZBuUOAm1H4quxA',NULL,'158.173.67.213','','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMzVIeW5nOWZyQWo2c1FqcVhwb3VNckJ5UXlucmJCQjI5N3ZPUzBFWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778697738),('6vIUCjHyFQ4F7KKWt63osjO0Zd4pFN9pbTtvc3Pd',NULL,'147.185.132.36','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoibjhBSHM4WTdhQkhYdXY5RkZTNWJFcjFSM2NUeElQSWRtZmVhZkplWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778866085),('6X0IudpPvNM1aC5WtVtMUWKPhbnKoYdROPAsfQtL',NULL,'34.91.213.89','Scrapy/2.13.4 (+https://scrapy.org)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSnlWVW9QS2k2ZkNqZXI1NlBMTmR1SWVmVjd5VHo1b3RpSFYzV2RrRSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vd3d3LmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1777563052),('9BaI5j49Rx3y9od76iUUTYZ7KriQcBSWNjXnIXWx',NULL,'188.166.150.85','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiV244ckhJelZMbUVEUURtMldNdGRPa3lXdUFjRjlrR250NlA2RE5KSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93d3cuaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778558909),('9CIkds8kYS0xwb1UP7nxfEC2LnzYwygbOB8B4Ehn',NULL,'185.247.137.136','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVmxpdHNSem03cUNybmpHdjZsOEF5TEhNdjQ0WEZ2OHNINU1Qbkl6eCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778358040),('9dmBeXjZlOyBv3E8AFCL3B68yWFabU3l3AuwTV9A',NULL,'199.45.154.118','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiT2M1STUwaW1GclB6SE94VzdTeUxud05MUEdQVGF0MmlZN2Y3cTFIcyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vd3d3LmludGVybmFsLmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1778830547),('AiM6CUXpA2lP4gQYexzpb0864n14gjG8Tkf89mnb',NULL,'176.65.148.161','Mozilla/5.0 (compatible; Let\'s Encrypt validation server; +https://www.letsencrypt.org)','YToyOntzOjY6Il90b2tlbiI7czo0MDoidnBWMmQyWlJIakRNalpqbDhRaXlnQW1ldmxTc3c2TkRtZEtCcnIzMiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777466922),('aJVPWjBi5kE3HtVDlKb528RRfyKOeIsao5Ym8HdI',NULL,'34.245.227.9','Mozilla/5.0 (compatible; NetcraftSurveyAgent/1.0; +info@netcraft.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQXVPWkRoWXpydXhPMlZndERyUFZlM1o4VmhDSHdDMVpPdndJYzE5NSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vd3d3LmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1778533685),('AsYyuBp1Z6g9PEItD1ISwp0Byaz35GglKrhxU0fX',NULL,'209.38.205.194','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWVBrYXUxZzhoWlJLajA1T3E2elNGdE9lRXFoUHhuY1pXaEtudFdLQSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93d3cuaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777372203),('B4hKIFvR4SKJWSuhWYiFVYnlR6GaFO2WFVZpO2NO',NULL,'93.158.90.73','Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115','YTozOntzOjY6Il90b2tlbiI7czo0MDoibnRaOVNBYWxRc2hRWTlUZmlxUlNRTjlHR3d5QjRXS1FvbkZoZDBKVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTA6Imh0dHA6Ly93d3cuYmVicmFzLmtvZGFwb3MuY29tL3NvYWwvcGVtYmFoYXNhbi1zb2FsIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777309199),('BaNofe6olgp78YOQHwXYuX5GWl7vW2kgagNCllNZ',NULL,'34.133.102.19','Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoidk9hdVg5NExVdThtN3hDdjByamhpY1JGdUl4bzRpMWJRVWxhS214RyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93d3cuaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777477806),('bbpZlfWBCjYJude4VwhwX3A9QKhBOEqIDSmM6KS4',NULL,'45.55.38.224','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoibWEwY3l4WTFiVzhSNHNxUjdqaUY0amZweFBMeENWZUZBWTZHOU1VZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1777362199),('BN9dD8EcOY1CZkAc9HftnFJh3BofMFBIorv1qPiP',NULL,'35.254.78.224','Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSGFxdVNWR3FyVnAzVDBrV2szZVFlMDlCMWNoNjZYZzhJRUtieGVCWCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1779118548),('C8V9OegYYuWvQKfBQcqd2USYk1QW0pxOHnN78k65',NULL,'205.210.31.177','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoidVM5QlNjam1wZkpIb21yTExNbGJuQ1g5aTN6VFpETHk4WThUWnFTeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1779117826),('CgbcR7widInfyKNgMkvMf01J6OU2WZQWG3vBTaZG',NULL,'192.71.38.130','Mozilla/5.0 (Linux; U; Android 13; sk-sk; Xiaomi 11T Pro Build/TKQ1.220829.002) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/112.0.5615.136 Mobile Safari/537.36 XiaoMi/MiuiBrowser/14.4.0-g','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWFU0NnBDaERheWZONmRmUXRic1Y0b3hpZUlmSjg5QW9LZHZRN09vTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly93d3cuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778256450),('D6HfviqyEHb2bbu9ivQVwNn523e0e7d7eVJQT97k',NULL,'199.45.154.155','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQzVEb1pBQ04xa1lFTXdIekwyTGV1ek9JQzJKTWdLQUVyUkVYNUhwMyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779211825),('dLcAYhzf0pbe0KXbNrb7UNqjsbwGdQN1yeok3Y11',NULL,'206.189.31.101','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaXQwRkIySVFieFVCcE10NlFCTHZtWHNPOG9icFJIbElkYXZ3clhCTSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly93d3cuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778938923),('EAC7xVjDfpuAKRYREzb4mq9F3GUg9cFE22c5WniF',NULL,'139.59.156.76','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUVdJeXdScnR0aGw5RWVRT3FFeWF4NmpyNGx3V0p1YXQ3Um8xTE1LZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vd3d3LmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1777702999),('EDIzf8YRk7De8FkLauhqm54X17ANcbW35sIBJQtC',NULL,'3.151.194.164','visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiREZYeEFMMHU0SElSZnQ3ZnNEZUhHTUpQQ0d5d3E4c21FclNSVGF3RCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9pbnRlcm5hbC5iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1777832140),('EiCZJ6G2JRBUo4wHSS5I0CTcpSABYrnYPqn4tKZ3',NULL,'3.139.242.79','visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZXVnVHJzdlhiV2N4cTljckcwVmVteUtNNmVodklaazBnTzFrZlpNTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1779089492),('eyq0WFCYnaq7xq01UZALLon4KMWGqaKkpjLz94vZ',NULL,'134.122.39.57','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiM0F6Z1ZWU1RNNmFha1Vib1J3VU9QaEhzS2ZQc3lQZmFNcWppUkI1QyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778221414),('Gi8xakOTNatpK8tOuTzye7ehaKvJUcsC8vseyLCP',NULL,'66.132.186.203','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoibGNUQUZOU2lNa2xHY1prN3RBdkdCRXdoUTJXdE5IZmpIR3JpQVZFaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vd3d3LmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1778683217),('gL1RmbZK0eVe4uzRDiZMhpLblucVg0Bz3OjycpJD',NULL,'87.236.176.208','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUW9ZSk1JSk5GVFFDNkt6cU14aVVKdXJIMFdJamRKeFR3ckhNbVZPQSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9pbnRlcm5hbC5iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778126175),('GrhK9ZUdgUhNLe9fFGJu9Lu9Yiey8T8W3BKTUubr',NULL,'98.84.1.175','RecordedFuture Global Inventory Crawler','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ0lqUk10bUxTREFlTzhQTkdMdGRoaDhxQlpvN2JXejJzY0FPTEliaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777711107),('GwDpu1a6BPSwJkkBGqDCO7rp9v2KvCYetFkj3N8Q',NULL,'147.182.212.183','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWmxUMVRzU2NxWUJNVUVsR09TQ1hoYWlQanVTb2I0NExIVHlxemJJbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9pbnRlcm5hbC5iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1777444504),('H0R6oSVq5jOAXxPLpGQaU2u2M26828EG6DfmVo8R',NULL,'34.1.21.82','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoidHFJcUdsODhqVDRnYU8yQmlrc2Q1UWhGNTVqTnY3ZjdtMnQxWGJlZiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93d3cuaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778659014),('IidEsb4R4HiEEnD0HEGaviAVuCys3XFVrskeJGhv',NULL,'206.189.31.101','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoieVhWSzVVclBuM0VCaW1iYlpBQmpCMXRpbTFESVBYODIyeGx2NURFdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vd3d3LmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1778938925),('Ijji1KwVXnmmpkMP6dhK9N6lPQVtr6krfF1HFlKS',NULL,'205.210.31.237','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUVF5SEs1THpBV01BNnFJSHQ4OGNKOVlWeEY0eUFKenBmbVg3aHF6OCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778576012),('iMV7yYPMYMcXMZrqcSsSJb0bgg6GW2dUZBnzgi34',NULL,'98.92.124.218','Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQUtWRXZZQ2k1dmJHVlNhYjlwckx6Nk1kTTZsaHFpN1VCSks4VHNMSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778737027),('io1PMhIp7Pria1OUHGx2SPkWjzL2GCFz1U5VdNA5',NULL,'136.119.232.152','Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWUNUSkNuS0VZV0g4V0ZKQXlac2xCOHdFVUNhUk5sSVM2V3RMOGpEbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93d3cuaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778771478),('JeHr6dvlJXWv7PLSUqx3K0QuBrozhPpTsnBm6SAG',NULL,'198.235.24.177','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOWdZY1RheVM4RUU1ZkRESnkxTjkzQUVGbjlVV0tSWThwR3NZaFJiMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9pbnRlcm5hbC5iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1779095436),('kAfuiHQMgDQtLrs7zPNVyLOHyG8wx13ITaoKZT4g',NULL,'176.65.148.161','Mozilla/5.0 (compatible; Let\'s Encrypt validation server; +https://www.letsencrypt.org)','YToyOntzOjY6Il90b2tlbiI7czo0MDoieGQ0THJ6eFZJMlJOaXJ1cVdsYVZNUXFnN0Q0Vkh0ZlRwYURQdFo2QSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777392264),('Kd2LjbJh8UbrFGhugsSQ5vNPLQFJNxVEVnemHWHS',NULL,'194.14.74.207','Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1.2 Mobile/15E148 Safari/604','YTozOntzOjY6Il90b2tlbiI7czo0MDoia2lUWFRZOWVpQmtRb2VLOUhtMEJDa2hJYTJCTUZCT3M4aHg4cExZYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93d3cuaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778517275),('kGmTtQq2624UiAq7sbDvTxCouiOnp2bwo2AyR98T',NULL,'34.1.23.90','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiN2dNRXRtanJEQWNaNjRaZXlwSHoyNDUxVlEwMWlsbVhyenlHU0I0cCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93d3cuaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777876283),('kK8XREDbYHTbA9OndkkhFCE2nexCvIYU65E8bhjo',NULL,'98.88.137.2','RecordedFuture Global Inventory Crawler','YTozOntzOjY6Il90b2tlbiI7czo0MDoiR1RCZlg5SkNNNTNzb3hsMlJRZmI1TmlHaERXYm4zWkVjUFpTVmpDTCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779248077),('kZ0qxtS0PXM33gnSCt07dVVS4Pme2bSaAsnySFE1',NULL,'34.91.213.89','Scrapy/2.13.4 (+https://scrapy.org)','YTozOntzOjY6Il90b2tlbiI7czo0MDoidXcydFZ1ZXNSNnNldFhLZDVTeExMbmFIbE5kYjB2eTV3SGVrS3l0eSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vd3d3LmludGVybmFsLmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1777562705),('M36eEL6x1KfH7CmzcoCKep4gkPpN6XcK8gNhNtL1',NULL,'44.245.220.91','Mozilla/5.0 (compatible; wpbot/1.4; +https://forms.gle/ajBaxygz9jSR8p8G9)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiV1pGOHZ3c0tLV1JScndGcUUwV1BGSHN0UmtDaFBhWXlBem55YXl3UiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778751229),('MQbJpkaZ1QRYDwNEwWJUrGB4hlENN0FD8TiYiZ98',NULL,'34.1.23.90','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVXRudHkwa0t0VVJ5YnlsSENpWDZCcDdkaHBxS0R1cmJEVWduWGU4cyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDQ6Imh0dHA6Ly93d3cuaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777876284),('NGsGAlNnNn9TL5U5BaBHm4UHCgwdsJuad6gTeIeF',NULL,'34.1.31.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiV3VsRGgxVEQ2WnNMbXV5V3JERjk0TjJVeWo5RzhncnhlMHU1MWY0eiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778661668),('nNGSYjUN7P0vtupTa6zcpYa5FTRHOfDu4BA72dQy',NULL,'139.59.156.76','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQXJJb1JPTXZLNFI0R1Y4NllWa1pKN0drb2VBQkFzTm4zTW1XaG1VbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly93d3cuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777702996),('oN13u5SEXg8IZIRkTvk7uMK18Y82UJyS21x1mPxK',NULL,'3.139.242.79','visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOUttSnY0akNjRWFzQ0xIbW83VGtRZDNQeVZheTdaVHcyWHBBM3hsUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779089523),('oT8HBIxGJ0S8bbYQOAX5AFHLHTcq4kWyf4H4ULMN',NULL,'34.193.251.180','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.85 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVRtZlAwb0p2eHdlVkN3TU1DcU1hZ0xHYk94TnpRcnNMS1A0VTN1TyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vd3d3LmludGVybmFsLmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1778834105),('OXKmnhV2LbepqEntjiEAU0OhIVfBzbopZOcE4hlI',NULL,'34.132.86.60','Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/21.0.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoidzRzZHM2Sk5kbThXd2Y0YUgwRTlkbUQ1d1dTZlIyVUV1eHZDcWFCcyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9pbnRlcm5hbC5iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778189048),('Q86qYJrRZUB0YC7Mf38XG1bx0vlyCU3JWlyHIk4f',NULL,'188.166.150.85','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoieXo2TWhIcG1XUFZMTzY0aGQwYkFaRzJIMlUxVkRFaHhtcnBFYVFuNSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vd3d3LmludGVybmFsLmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1778558910),('qJlX3L3pHXEdRiteQ44BLCLKc9HKUR6R8FCkKuDf',NULL,'186.179.59.133','Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVlJJdWhYZWc5ekFhTnRQWjRHZVF3QVN4aXFWUGh4Z0liaGdSQmJQZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778737029),('qN7Dy6h5MXjdMH0qSe4i2uO69fHIWVCMBRf0k8d5',NULL,'146.190.162.146','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVJCeW5UajZYTmlNMzRGd1pRWTJxUVhjaEs1TlMzYUJqUnc2WldSUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778675440),('R5UyOSKJRESQ52KH2NC49Xr5gQ1TbLClwu5FQlDP',NULL,'34.1.31.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNGt6VGFlamlOZmNZQUtPUmJaWW40MHc5SEVCNXdHNmJVRWRiaDlIOCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly93d3cuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778661674),('rA1O9yucoMyczvYH6YJjI4Uhc92202bRhfNLgE24',NULL,'34.30.242.19','Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNFpmSTdOMGRUbWlHWFZENkhXNTVQdGtyeHN3OUR1WjlHblRSTXBQUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778770560),('rCkxQkqCJ8rVp2RRWnetfiIHHUe3LezpsucL8lCK',NULL,'93.158.90.67','Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115','YTozOntzOjY6Il90b2tlbiI7czo0MDoid2V2N1VwbUdSSm5CNjUxY0M3b0oweWFrSUs3M0o3N0U2TXo4ZHRFcSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDk6Imh0dHA6Ly93d3cuYmVicmFzLmtvZGFwb3MuY29tL3NvYWwvcGVuZ2dhbGFuZy1zbXAiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1777309199),('rFXEDJCK5vQr6CEV7SEQ3UJZMdPYNJS8IfTFPa6p',NULL,'34.1.21.82','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiT1NaQ3o1SlpjTWxqNG1VU3pVVnhyU1FTNXlPUzczbUdqdHRLRzhwMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDQ6Imh0dHA6Ly93d3cuaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778659016),('RjScB7UDIWZQJDNELGAqScw94RvBmHSVHXiYMEMv',NULL,'221.239.90.68','Mozilla/5.0 (Linux; Android 12; redroid12_arm64 Build/SQ1D.220205.004; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/122.0.6261.119 Mobile Safari/537.36 uni-app','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOXVla1ByeVY4bUdQcjBLUGdMb0lBZWR0UXBWbFRzZ1BiWDVkSHJPWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778732778),('sjq56l0qjI3fsLkM97XPUMpaTTgUPBg1dXN7MTXF',NULL,'35.253.160.125','Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiR1VLNGpBSUpNakV4VWVUeWZaT0ZnZHJydnFwcm5QVG1mRzZOeFBoSiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93d3cuaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779126947),('T7kyfmaaXNBORwDlaF7kqRy0nzqjg5WRAdJu216z',NULL,'129.226.155.16','Mozilla/5.0 (Linux; Android 10; LIO-AN00 Build/HUAWEILIO-AN00; wv) MicroMessenger Weixin QQ AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.62 XWEB/2692 MMWEBSDK/200901 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWnVBNkxkRTg3WUFTZ1BVakJjam1MSGlzUzJGUWNVWm5ORTZHcjA1dSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778738311),('TNv3tizL7y8vweVhHxQPb7bLDxbHuADpmOKWH8An',NULL,'74.7.227.23','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRHhiQ1lqd3FBWkEwMUM5cUlqOE5EZ29Lbmc3SmNFbkx4ZER1anBncSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vd3d3LmludGVybmFsLmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1777710535),('TzvfAHx04unOLoF43mCMqZisxJGzIUEuOzElBBDU',NULL,'74.7.241.29','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNVRUT0RFTnF6QjZTYmYzUElkVzE2MnlaR1oxMVdzUTc5UE5MdXNwNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777722824),('vLbujAPMbjlicNpUPSE1LkKpRHT8kxzLH6apqbBY',NULL,'185.213.175.92','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUTZRMGsxczJJeDNPaUEzQWd4Sm5KZWxJeXpKT0Y4RXBEM3ZKeE5GVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778137911),('wJMwiuvjOPh9Ntx0LOiRs0auCwvIl68P1k3sr1da',NULL,'191.102.162.107','Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoibk9adkhWQmN6WlhJN0tHNklPU20zdGgzODlHYXdXdk1BRnJsZDlqMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778737028),('XiaNAdgNqG5DhkH5wuZhf6N24rlmPGYLYfOIlBpw',NULL,'98.92.124.218','Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2ZhRlhyMWV1WXphWlZUZ2hkeGUzelJaSW9ramZXR252ZUxrMWEweCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778737027),('Xpw5G45BkzuBEeCE5BYbLfwAQz798zvWvFsjw8qm',NULL,'205.210.31.19','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTkJVVTU4V3lnNUZ6QnFaOVkyb2hGSFg1eE9XZWcxc3lGckxpb2NsVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1779193918),('y9BhK4BLNGSUYyDVfiW83VQ2BTiAQ8WP7QO8KCeE',NULL,'74.7.227.189','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiakpkc0pmRUY0QWdwYWN2NGh2MDlrclFkYWZZWDltMjVieFpVR0VTdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDI6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tL3NvYWwvaW5kZXgtc29hbCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1777805720),('Ya9ex1pJcpYSyZ3yF0xJOVcskUo9LhYi4p0JMl4M',NULL,'167.99.76.73','WP-Safe-Scanner/2.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYW83TEllU2lZMVFYOG1WeXFRQ1ZnU1FER1h2NXE3RDM5b2M3YU5HSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9pbnRlcm5hbC5iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778984890),('Yf0BGOnugD3QAalI5rHzMSlkEPa76TPJOWrkBhQI',NULL,'147.182.212.183','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiY291alhOcWM0V2lZb0M5TlZLRVN4a3RUZVFPd3NJOVQ4NXJUQ3NGSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777444504),('YIOrqBIDuIF1XWE1icn9OAV6g3WFxEhRE4URiui3',NULL,'45.55.38.224','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiejdKRktUM3Z6clZJR0lXOVFxUFdkbWQxWXl4OFJoNEZKZVA2Qk9BTSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777362200),('YmOvB9PLLPytWNIbUlVINEaClN9LY4un8neuQ6ii',NULL,'54.88.24.205','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/138.0.7204.23 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiOWU1NGZxSHFubHQ1am5Ga0ZsbzRSN2dIbGpFQ0xjeXBUcGVTTEQxUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778737661),('yS6KVzCNnxj6jYCrjzQFrfqyMPfRUc4BdzJsmR2M',NULL,'193.183.95.187','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.3','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYlFhME5aYU9leno3Mzl4ZXJ3aU9USDVERG9rT1V1UVc2YWhXVFdGbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9pbnRlcm5hbC5iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778450238),('YZdphIChCCmEW3xWUsIVnzXvgMGonKFhAEn4UBSZ',NULL,'221.239.90.68','Mozilla/5.0 (Linux; Android 12; redroid12_arm64 Build/SQ1D.220205.004; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/122.0.6261.119 Mobile Safari/537.36 uni-app','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSUUxTnI2OFJ4dFBMQ0VPaWtRNjJBQnpDNEJJeGlaZUt2T3JZelQxdCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9pbnRlcm5hbC5iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778754026),('YzXmlVchqWmZBvsla3Orm3kzbtuGpVg1WSypAL91',NULL,'199.45.154.142','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoibjFmSFdjZjFkUWJ4Q2ZlU2ZMNHl3V2RHSTEzT1FjMDA5SVpVOWZ6SSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly93d3cuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778683169),('zCDPnCGvBnxvrJA04EXSprIHVUqhfDfGEUnKRVHO',NULL,'3.255.159.98','Mozilla/5.0 (compatible; NetcraftSurveyAgent/1.0; +info@netcraft.com)','YTozOntzOjY6Il90b2tlbiI7czo0MDoianNHYzRtWVd1aUVVSnZyR2R2eno0ZnhyeVZGUEM4YjBvUHFRYU1raSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vaW50ZXJuYWwuYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1778515212),('ZF5JRp72iOHoeqAo3sH95tkiVB5OJVRfUbETFuAt',NULL,'195.178.110.186','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/122.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoidTYzeWhaM1pGOUJkMEhLeFkybmtnTUMyOWlSSjRadWRhRWdlMHgzMyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vYmVicmFzLmtvZGFwb3MuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1777948329),('zMb8qZ8HFH1ptRgiJ86BRCVO3vg2hE1dYFFZAmOJ',NULL,'209.38.205.194','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTDI1aWJCZ3dGbTVobkgxa2MyYmp5TGJrenVvbFliT2FxRHJTV2ZqdyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vd3d3LmludGVybmFsLmJlYnJhcy5rb2RhcG9zLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1777372203),('Znoh7Os7gT17E3B9u7Ibyn7jfT9ZcghD9KaCIc5g',NULL,'167.99.76.73','WP-Safe-Scanner/2.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSzh4WmxIQ1FYQjdsemJKd01QS0JkRHV1Vk45bnNkTnpmSTdRc200ZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778984889),('zwNwzKoxE4IXL5KdxThAeVDDiSMtT9DtvdQLv178',NULL,'146.190.162.146','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTjU1M25QMlhkSGx6MDRlc0xnUHY1WDdNODN3TGpBVTdYTUd2VGdqUCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9pbnRlcm5hbC5iZWJyYXMua29kYXBvcy5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1778675439);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tentang_bebras`
--

DROP TABLE IF EXISTS `tentang_bebras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tentang_bebras` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `konten` longtext NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `urutan` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tentang_bebras_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tentang_bebras`
--

LOCK TABLES `tentang_bebras` WRITE;
/*!40000 ALTER TABLE `tentang_bebras` DISABLE KEYS */;
/*!40000 ALTER TABLE `tentang_bebras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES (1,'Admin','admin','admin@example.com','$2y$12$dBgE1l/0096wYUuOExmi5OYim1nUyx0NtMA50B5wvGb6UhbMpy402',NULL,'2025-10-03 05:44:02','2025-10-03 05:44:02'),(2,'User 1','user_1','user@example.com','$2y$12$w7xQLPbvCwv.GQMUmZe8cOEOEVDgiSxRwUcTQewEOPV1shzN9LA.m',NULL,'2025-10-03 05:44:03','2025-10-03 05:44:03');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'kodaposc_bebras_db'
--

--
-- Dumping routines for database 'kodaposc_bebras_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-20 10:49:41
